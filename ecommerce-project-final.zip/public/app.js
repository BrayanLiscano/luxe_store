document.addEventListener('DOMContentLoaded',()=>{
  let productos=[];
  let carrito=JSON.parse(localStorage.getItem('cart')||'[]');
  const lista=document.getElementById('lista-productos');
  const buscar=document.getElementById('buscar');
  const carritoEl=document.getElementById('carrito');
  const abrirCarrito=document.getElementById('abrir-carrito');
  const cerrarCarrito=document.getElementById('cerrar-carrito');
  const itemsEl=document.getElementById('carrito-items');
  const totalEl=document.getElementById('carrito-total');
  const countEl=document.getElementById('cart-count');
  const vaciar=document.getElementById('vaciar-carrito');
  const checkout=document.getElementById('checkout');

  function formatPrice(n){return '$'+Number(n).toLocaleString('es-CO');}

  function renderProductos(cat='Todas',q=''){
    q=q.toLowerCase();
    const filtrados=productos.filter(p=>
      (cat==='Todas'||p.categoria===cat) &&
      (p.nombre.toLowerCase().includes(q)||p.descripcion.toLowerCase().includes(q))
    );
    lista.innerHTML='';
    filtrados.forEach(p=>{
      const card=document.createElement('div');
      card.className='card';
      card.innerHTML=`<img src="${p.imagen}"><h3>${p.nombre}</h3><p>${p.descripcion}</p><div class="price">${formatPrice(p.precio)}</div><button class="btn-primary" onclick="addToCart(${p.id})">Agregar</button>`;
      lista.appendChild(card);
    });
  }

  function renderCarrito(){
    itemsEl.innerHTML='';
    let total=0;
    carrito.forEach(it=>{
      const prod=productos.find(p=>p.id===it.id);
      if(!prod)return;
      total+=prod.precio*it.cantidad;
      const div=document.createElement('div');
      div.innerHTML=`${prod.nombre} x${it.cantidad} - ${formatPrice(prod.precio*it.cantidad)}`;
      itemsEl.appendChild(div);
    });
    totalEl.textContent='Total: '+formatPrice(total);
    countEl.textContent=carrito.reduce((s,i)=>s+i.cantidad,0);
    localStorage.setItem('cart',JSON.stringify(carrito));
  }

  window.addToCart=id=>{
    const item=carrito.find(i=>i.id===id);
    if(item)item.cantidad++; else carrito.push({id,cantidad:1});
    renderCarrito();
  };

  abrirCarrito.addEventListener('click',()=>carritoEl.classList.add('open'));
  cerrarCarrito.addEventListener('click',()=>carritoEl.classList.remove('open'));
  vaciar.addEventListener('click',()=>{carrito=[];renderCarrito();});
  checkout.addEventListener('click',()=>{alert('Compra realizada!');carrito=[];renderCarrito();});

  buscar.addEventListener('input',()=>renderProductos('Todas',buscar.value));

  fetch('/api/productos').then(r=>r.json()).then(data=>{productos=data;renderProductos();renderCarrito();});
});
