const express = require('express');
const cors = require('cors');
const app = express();
const productos = require('./productos.json');

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Endpoint productos
app.get('/api/productos', (req, res) => {
  res.json(productos);
});

// Endpoint producto por id
app.get('/api/productos/:id', (req, res) => {
  const prod = productos.find(p => p.id == req.params.id);
  if (!prod) return res.status(404).json({error: 'Producto no encontrado'});
  res.json(prod);
});

// Orden de compra (simulada)
let ordenes = [];
app.post('/api/ordenes', (req, res) => {
  const { usuario, items, total } = req.body;
  const nueva = { id: ordenes.length + 1, usuario, items, total, fecha: new Date() };
  ordenes.push(nueva);
  res.json(nueva);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Servidor corriendo en http://localhost:' + PORT));
